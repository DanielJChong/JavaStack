public class Node {
    public int value;
    public Node next;
    public Node(int value) {
        // your code here
    }
    constructor(data) {
        this.data = data;
        this.next = null;
    }
}