package com.daniel.zookeeper;

public class Bat extends Mammal{

	public Bat(int energyLevel) {
		super(300);
	}
	public void fly() {
		System.out.println("Screech!");
		energyLevel -= 50;
	}
	public void eatHumans() {
		System.out.println("Yummy humans!");
		energyLevel += 25;
	}
	public void attackTown() {
		System.out.println("Burn baby burn");
		energyLevel -= 100;
	}
}
