//package com.daniel.zookeeper;
//
//public class GorillaTest {
//
//	public static void main(String[] args) {
//		Gorilla g = new Gorilla();
//		g.displayEnergy();
//		
//		g.throwSomething(); 
//		g.throwSomething(); 
//		g.throwSomething();
//		
//		g.eatBanana();
//		g.eatBanana();
//		
//		g.climb();
//		
//		g.displayEnergy();
//
//	}
//
//}
