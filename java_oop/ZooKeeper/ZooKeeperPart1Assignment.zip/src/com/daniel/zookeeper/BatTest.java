//package com.daniel.zookeeper;
//
//public class BatTest {
//
//	public static void main(String[] args) {
//		Bat b = new Bat();
//		
//		b.fly(2);
//		
//		b.eatHumans(2);
//		
//		b.attachTown(3);
//
//	}
//
//}
