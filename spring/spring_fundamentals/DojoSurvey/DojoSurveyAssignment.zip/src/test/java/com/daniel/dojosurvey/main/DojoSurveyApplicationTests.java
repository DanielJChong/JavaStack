package com.daniel.dojosurvey.main;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DojoSurveyApplicationTests {

	@Test
	void contextLoads() {
	}

}
