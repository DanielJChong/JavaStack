package com.daniel.hellohuman;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class HelloHumanApplicationTests {

	@Test
	void contextLoads() {
	}

}
