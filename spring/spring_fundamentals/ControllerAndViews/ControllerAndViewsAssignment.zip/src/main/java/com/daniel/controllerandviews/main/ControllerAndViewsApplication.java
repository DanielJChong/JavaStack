package com.daniel.controllerandviews.main;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ControllerAndViewsApplication {

	public static void main(String[] args) {
		SpringApplication.run(ControllerAndViewsApplication.class, args);
	}

}
