package com.daniel.controllerandviews.main;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ControllerAndViewsApplicationTests {

	@Test
	void contextLoads() {
	}

}
