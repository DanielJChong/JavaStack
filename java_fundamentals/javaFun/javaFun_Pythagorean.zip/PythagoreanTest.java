public class PythagoreanTest {
    public static void main(String[] args) {
        Pythagorean iD = new Pythagorean();
        double answer = iD.calculateHypotenuse(3,4);
        System.out.println(answer);
    }
}
